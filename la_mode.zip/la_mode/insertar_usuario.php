<!-- Php para guardar los usuarios en la base de datos -->



<?php  
	// Inclusion de la conexion general a la base de datos
	include 'db/conect_db.php';

	// Definicio de las variables a guardar en la base de datos
		 
	if (isset($_POST['registrar'])) {
		
		$nombre = $_POST['nombre'];
		$correo = $_POST['correo'];
		$contraseña = $_POST['contraseña'];
		
	// Variable que ingresara los datos a la base de datos
		
		$insertar = "INSERT INTO usuarios(name, mail, password) 
				     VALUES ('$nombre', '$correo', '$contraseña')";

	// Validacion para evitar que el campo "nombre"se repita en la base de datos

		$v_nombre = mysqli_query($conexion_general, "SELECT * FROM usuarios WHERE name ='$nombre'");

		if (mysqli_num_rows($v_nombre) > 0) {
			
			echo '<script>
					alert("El nombre que ingreso ya ha sido registrado, po favor intente con otro");
					window.location = "registrar_usuario.php";
				  </script>' ;	
			exit();
		}

	// Validacion para evitar que el campo "correo"se repita en la base de datos

		$v_correo = mysqli_query($conexion_general, "SELECT * FROM usuarios WHERE mail ='$correo'");

		if (mysqli_num_rows($v_correo) > 0) {
			
			echo '<script>
					alert("El correo que ingreso ya ha sido registrado, po favor intente con otro");
					window.location = "registrar_usuario.php";
				  </script>' ;	
			exit();
		}

	// Variable que despues de la validacion guardara los datos en la base de datos
		$consulta = mysqli_query($conexion_general, $insertar);

		if ($consulta){
			echo '<script>
					alert("Usuario Registrado Exitosamente");
					window.location = "registrar_usuario.php";
				  </script>';
		}

	}
	
?>