<!-- Vista del index general -->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">

		<title>La Mode</title>

	<!-- Css de bootstrap -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<!-- Css de Font Awesome -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<!-- Css personalizado -->
		<link rel="stylesheet" type="text/css" href="css/index.css">
		<!-- encabezado de la pagina -->
		<link rel="icon" href="img/mode.png" type="image/png" style=" width:500px;  height:700px;">

	</head>	

	<body>

	<!-- Div Principal -->

		<div class="contenedor_principal">

		<!-- Div del slider -->

			<div class="contenedor_slider">

				<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
		
					<div class="carousel-inner">

						<div class="carousel-item active">
							<img src="img/fondo_1.jpg" class="d-block w-100">
					  	</div>

					  	<div class="carousel-item">
							<img src="img/fondo_2.jpg" class="d-block w-100">
					  	</div>

					  	<div class="carousel-item">
							<img src="img/fondo_3.jpg" class="d-block w-100">
					  	</div>
	
					</div>

					<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">

						<span aria-hidden="true"><i class="fas fa-chevron-left"></i></span>

						<span class="visually-hidden"></span>

					</button>

					<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">

						<span aria-hidden="true"><i class="fas fa-chevron-right"></i></span>

						<span class="visually-hidden"></span>

					</button>
					
				  </div>

			</div>

		<!-- Div de la barra del menu -->

			<div class="contenedor_menu">
				
				<ul>

					<li class="logo">
						
						<h1 class="h_1"> Shoes Store La Mode </h1>

					</li>

					<li class="li_1"> 
						<a href="productos/niña_index.html"> Niña </a> 
					</li>

					<li class="li_2"> 
						<a href="productos/niño_index.html"> Niño </a> 
					</li>

					<li class="li_3"> 
						<a href="productos/mujer_index.html"> Mujer </a> 
					</li>

					<li class="li_3"> 
						<a href="productos/hombre_index.html">Hombre </a> 
					</li>


					<li class="cuenta"> <i class="fas fa-user-circle"></i> Cuenta

						<ul>

							<li>
								<i class="far fa-user"></i> <a href="login_usuario.php"> Iniciar Sesión </a>
							</li>

							<li>
								<i class="far fa-address-card"></i> <a href="registrar_usuario.php"> Registrase </a>
							</li>

							<li>
								<i class="fas fa-sign-in-alt"></i> <a href="index.php"> Cerrar Sesión </a>
							</li>

						</ul>

					</li>

					<li class="acerca">

						<i class="fas fa-info-circle"></i> <a href="acerca.html"> Acerca de Nosotros </a>

					</li>

				</ul>
				
			</div>

		<!-- Div de los productos -->

			<div class="contenedor_productos">

				<div class="h1">

					<h1 class="titulo_productos">Nuestros Estilos</h1>
					
				</div>

				<div class="contenedor_items">

					<div class="items">

						<img src="productos/productos/zapatos_niño/index_1.jpg" width="100%" height="80%" class="img">

						<h5 class="h_name">Zapato para niño</h5>

						<h5 class="h_costo">$ 13.00</h5>

					</div>

					<div class="items">

						<img src="productos/productos/zapatos_niña/index_1.jpg" width="100%" height="80%" class="img">

						<h5 class="h_name">Zandalias para niña</h5>

						<h5 class="h_costo">$9.00</h5>
						
					</div>

					<div class="items">

						<img src="productos/productos/zapatos_hombre/index_1.jpg" width="100%" height="80%" class="img">

						<h5 class="h_name">Zapato tenis para hombre</h5>

						<h5 class="h_costo">$23.00</h5>

					</div>

					<div class="items">

						<img src="productos/productos/zapatos_mujer/index_1.jpg" width="100%" height="80%" class="img">

						<h5 class="h_name">Zapato tenis para mujer</h5>

						<h5 class="h_costo">$29.00</h5>

					</div>



				</div>
		
		</div>

	<!-- Scripts de boorstrap -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

	</body>

</html>


