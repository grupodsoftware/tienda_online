<?php
	
	// $conexion_general = mysqli_connect('Localhost',
	// 								   'id17338800_root',
	// 								   ']lf&L8]?~u=nSWBO',
	// 								   'id17338800_tienda');

	$conexion_general = mysqli_connect('Localhost',
									   'root',
									   '',
									   'id17338800_tienda_online');


	// if ($conexion_general) {
	// 	echo "Conectado";
	// }


	// if (!$conexion_general) {
	// 	echo "Error al conectarse";
	// }

?>



