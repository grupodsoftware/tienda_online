<!-- Validaio de inicio de sesion de os usuarios -->

<?php  

	include 'db/conect_db.php';

	if (isset($_POST['iniciar'])) {
		
		$correo = $_POST['correo'];
		$contraseña = $_POST['contraseña'];

	$v_inicio = mysqli_query($conexion_general, "SELECT * FROM usuarios WHERE mail = '$correo' and 
		        															  password = '$contraseña' ");

	if (mysqli_num_rows($v_inicio) > 0) {

		header("location: index.php");
		
		exit;

	}else{

		echo '<script>
				  alert("Los datos que ingreso no estan registrados, porfavor verifique sus datos o registrese");
			      window.location = "login_usuario.php";
			  </script>';
		exit;	
	}

}

?>